#include <iostream>
using namespace std;

char C = 'Y', W = ' ', N = ' ', E = ' ', S = ' ';
char W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
string dir, pos = "central hallway";
int  key = 0;
bool gotKeySE = 0, gotKeyWN = 0, gotKeyNW = 0, win = 0;

int board(string pos){
	system("clear");
	cout << "\n\n\tHallways\nThe character 'Y' marks your position\nEnter command west, east, north or south to move around.\nEnter command quit to leave game.\n\n";
	cout << endl;
	cout << "        _____________________         " << endl;
	cout << "       |                     |        " << endl;
	cout << "       | "<<N1<<"        "<<N<<"       "<<N2<<"  |        " << endl;
	cout << " ______|_______       _______|______  " << endl;
	cout << "|  "<<W1<<"   |       |     |       |  "<<E1<<"   | " << endl;
	cout << "|      |       |     |       |      | " << endl;
	cout << "|      |_______|     |_______|      | " << endl;
	cout << "|                                   | " << endl;
	cout << "|  "<<W<<"              "<<C<<"              "<<E<<"  | " << endl;
	cout << "|       _______       _______       | " << endl;
	cout << "|      |       |     |       |      | " << endl;
	cout << "|  "<<W2<<"   |       |     |       |  "<<E2<<"   | " << endl;
	cout << "|______|_______|     |_______|______| " << endl;
	cout << "       |                     |        " << endl;
	cout << "       |"<<S1<<"         "<<S<<"        "<<S2<<" |        " << endl;
	cout << "       |_____________________|        " << endl << endl;
	cout << "You are at : " << pos << endl << endl;
	return 0;
}
int main(){
/*
this is for the central hallways located in the first floor.
The step is quite easy, this could be an example for this
kind of data handling
*/
	while(win != 1){
//CENTRAL HALLWAY
		while(C == 'Y' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			board("central hallway");
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = 'Y', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = 'Y', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = 'Y', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("east hallway");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = 'Y', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("south hallway");
			}else if(dir == "quit"){
				return 0;
			}
		}
//WEST HALLWAY
		while(C == ' ' && W == 'Y' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = 'Y', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = 'Y', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway north");
				if(gotKeyWN == 0){
				cout << "You have found one of the key part..." << endl;
				key++;
				cout << "Key parts : " << key << "/3" << endl;
				gotKeyWN = 1;
			}
			}else if(dir == "east"){
				C = 'Y', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("central hallway");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = 'Y', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway south");
			}else if(dir == "quit"){
				return 0;
			}
		}
//NORTH HALLWAY
		while(C == ' ' && W == ' ' && N == 'Y' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = 'Y', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway west");
				if(gotKeyNW == 0){
					key++;
					cout << "You have found a part of key..." << endl;
					cout << "Key parts : " << key << "/3" << endl;
					gotKeyNW = 1;
				}
			}else if(dir == "north"){
				C = ' ', W = ' ', N = 'Y', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = 'Y', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway east");
			}else if(dir == "south"){
				C = 'Y', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("central hallway");
			}else if(dir == "quit"){
				return 0;
			}
		}
//EAST HALLWAY
		while(C == ' ' && W == ' ' && N == ' ' && E == 'Y' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = 'Y', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("central hallway");
			}else if(dir == "north"){
				if(key != 3){
					C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = 'Y', E2 = ' ', S1 = ' ', S2 = ' ';
					board("Gate");
					cout << "To get out, find all the key parts\n";
					cout << "Key parts : " << key << "/3" << endl;
				}else if(key == 3){
					C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
					board("Gate\nYou have all the key parts to open the gate, thanks for spending time!\nPress ctrl + C to continue...");
					cin >> dir;
					win = 1;
				}
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = 'Y', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("east hallway");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = 'Y', S1 = ' ', S2 = ' ';
				board("east hallway south");
			}else if(dir == "quit"){
				return 0;
			}
		}
//SOUTH HALLWAY
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == 'Y' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = 'Y', S2 = ' ';
				board("south hallway west");
			}else if(dir == "north"){
				C = 'Y', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("central hallway");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = 'Y';
				board("south hallway east");
				if(gotKeySE == 0){
					key++;
					cout << "You have found a part of key..." << endl;
					cout << "Key parts : " << key << "/3" << endl;
					gotKeySE = 1;
				}
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = 'Y', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("south hallway");
			}else if(dir == "quit"){
				return 0;
			}
		}
/*
WEST HALLWAY ELEMENTS
*/
//W1
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == 'Y' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = 'Y', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway north");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = 'Y', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway north");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = 'Y', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway north");
			}else if(dir == "south"){
				C = ' ', W = 'Y', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway");
			}else if(dir == "quit"){
				return 0;
			}
		}
//W2
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == 'Y' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = 'Y', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway south");
			}else if(dir == "north"){
				C = ' ', W = 'Y', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = 'Y', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway south");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = 'Y', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("west hallway south");
			}else if(dir == "quit"){
				return 0;
			}
		}
/*
NORTH HALLWAY ELEMENTS
*/
//N1
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == 'Y' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = 'Y', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway west");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = 'Y', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway west");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = 'Y', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = 'Y', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway west");
			}else if(dir == "quit"){
				return 0;
			}
		}
//N2
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == 'Y' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = 'Y', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = 'Y', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway east");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = 'Y', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway east");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = 'Y', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("north hallway east");
			}else if(dir == "quit"){
				return 0;
			}
		}
/*
EAST HALLWAY ELEMENTS
*/
//E1
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == 'Y' && E2 == ' ' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = 'Y', E2 = ' ', S1 = ' ', S2 = ' ';
				board("east hallway north");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = 'Y', E2 = ' ', S1 = ' ', S2 = ' ';
				board("east hallway north");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = 'Y', E2 = ' ', S1 = ' ', S2 = ' ';
				board("east hallway north");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = 'Y', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("east hallway");
			}else if(dir == "quit"){
				return 0;
			}
		}
//E2
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == 'Y' && S1 == ' ' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = 'Y', S1 = ' ', S2 = ' ';
				board("east hallway south");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = ' ', E = 'Y', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("east hallway");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = 'Y', S1 = ' ', S2 = ' ';
				board("east hallway south");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = 'Y', S1 = ' ', S2 = ' ';
				board("east hallway south");
			}else if(dir == "quit"){
				return 0;
			}
		}
/*
SOUTH HALLWAY ELEMENTS
*/
//S1
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == 'Y' && S2 == ' '){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = 'Y', S2 = ' ';
				board("south hallway west");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = 'Y', S2 = ' ';
				board("south hallway west");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = 'Y', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("south hallway");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = 'Y', S2 = ' ';
				board("south hallway west");
			}else if(dir == "quit"){
				return 0;
			}
		}
//S2
		while(C == ' ' && W == ' ' && N == ' ' && E == ' ' && S == ' ' && W1 == ' ' && W2 == ' ' && N1 == ' ' && N2 == ' ' && E1 == ' ' && E2 == ' ' && S1 == ' ' && S2 == 'Y'){
			cin >> dir;
			if(dir == "west"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = 'Y', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = ' ';
				board("south hallway");
			}else if(dir == "north"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = 'Y';
				board("south hallway east");
			}else if(dir == "east"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = 'Y';
				board("south hallway east");
			}else if(dir == "south"){
				C = ' ', W = ' ', N = ' ', E = ' ', S = ' ', W1 = ' ', W2 = ' ', N1 = ' ', N2 = ' ', E1 = ' ', E2 = ' ', S1 = ' ', S2 = 'Y';
				board("east hallway east");
			}else if(dir == "quit"){
				return 0;
			}
		}
	}
	return 0;
}
