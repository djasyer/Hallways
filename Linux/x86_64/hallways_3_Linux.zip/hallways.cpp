#include <iostream>
using namespace std;

void card(){
	cout << "maybe try looking south up there?\n";
}
int main(){
	string hi = "\n\nHallways (initial copy) - A project by ASYEREAL. This game holds\nthe theme adventure and mystery. To play, you use commands.\nCommands are compass points like [\"west, north, east, south\"].\nIf you encounter staircases, you can go up and down by\njust typing [\"up\" or \"down\"].\nCommands are typed without brackets and without quotation marks\n\n";
	string hi2 = "You are in a dark, old castle. Navigate through the hallways to get out.";
	string pos = "central hallway 1", dir, loc = "You\'re in : ", ent = "\n\n", walls = "[WALLS]\n";
	string lol = "Level : ";
	string message = "You saw an apparition of a man in the Workers hostel.\n", level = "1";
	bool havekey = 0, havecard = 0, win = 0;
	cout << hi + ent;
	cout << hi2 + ent;
	cout << loc + pos + ent;
	
	while(win == 0 || win != 1){
				/*

				THIS IS FOR FLOOR ONE

				*/

		while(level == "1"){
/*CENTRAL HALLWAY 1*/
			while(pos == "central hallway 1"){
				cin >> dir;
				if(dir == "west"){
					pos = "west hallway 1";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "north hallway 1";
					cout << loc + pos + ent;
				}if(dir == "east"){
					pos = "east hallway 1";
					cout << loc + pos + ent;
				}if(dir == "south"){
					pos = "south hallway 1";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*WEST HALLWAY 1*/
			while(pos == "west hallway 1"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "workers hostel";
					cout << loc + pos + ent;
					if(havecard == 0){
						cout << message;
						cout << "by the way, you have found a piece of paper containing some messages.\n Use the command [\"read\"] to see contents...\n";
						havecard = 1;
					}
				}if(dir == "east"){
					pos = "central hallway 1";
					cout << loc + pos + ent;
				}if(dir == "south"){
					pos = "west staircase 1";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*NORTH HALLWAY 1*/
			while(pos == "north hallway 1"){
				cin >> dir;
				if(dir == "west"){
				pos = "cafeteria";
					cout << loc + pos + ent;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					pos = "kitchen";
					cout << loc + pos + ent;
				}if(dir == "south"){
					pos = "central hallway 1";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*EAST HALLWAY 1*/
			while(pos == "east hallway 1"){
				cin >> dir;
				if(dir == "west"){
				pos = "central hallway 1";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "restroom 1";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "east staircase 1";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*SOUTH HALLWAY 1*/
			while(pos == "south hallway 1"){
				cin >> dir;
				if(dir == "west"){
				pos = "gallery";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "central hallway 1";
					cout << loc + pos + ent;
				}if(dir == "east"){
					pos = "gate";
					cout << pos + ent;
					if(havekey == 1){
						pos = "win";
						cout << "you have managed to get out! Press enter to continue...\n";
						cin >> dir;
						if(dir == ""){
							return 0;
						}
					}if(havekey == 0){
						cout << "the gate is locked you must firstly find the key to get out of this place...\n";
					}
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
			
/*
WEST HALLWAY 1 ELEMENTS
*/
/*workers hostel*/
			while(pos == "workers hostel"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "west hallway 1";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*west staircase 1*/
			while(pos == "west staircase 1"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "west hallway 1";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}if(dir == "up"){
					pos = "west staircase 2";
					level = "2";
					cout << lol + level + ent;
					cout << loc + pos + ent;
				}if(dir == "down"){
					pos = "west staircase 0";
					level = "0";
					cout << lol + level + ent;
					cout << loc + pos + ent;
				}
			}
/*
NORTH HALLWAY 1
*/
/*cafeteria*/
			while(pos == "cafeteria"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					pos = "north hallway 1";
					cout << loc + pos + ent;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*kitchen*/
			while(pos == "kitchen"){
				cin >> dir;
				if(dir == "west"){
					pos = "north hallway 1";
					cout << loc + pos + ent;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*
EAST HALLWAY 1 ELEMENTS
*/
/*restroom 1*/
			while(pos == "restroom 1"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "east hallway 1";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*east staircase 1*/
			while(pos == "east staircase 1"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "east hallway 1";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}if(dir == "up"){
					pos = "east staircase 2";
					level = "2";
					cout << lol + level + ent;
					cout << loc + pos + ent;
				}if(dir == "down"){
					pos = "east staircase 0";
					level = "0";
					cout << lol + level + ent;
					cout << loc + pos + ent;
				}
			}
/*
SOUTH HALLWAY 1 ELEMENTS
*/
/*gallery*/
			while(pos == "gallery"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					pos = "south hallway 1";
					cout << loc + pos + ent;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*gate*/
			while(pos == "gate"){
				cin >> dir;
				if(dir == "west"){
					pos = "south hallway 1";
					cout << loc + pos + ent;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
		}
		
				/*
				
				THIS IS FOR LEVEL 2
				
				*/
				
	while(level == "2"){
/*CENTRAL HALLWAY 2*/
			while(pos == "central hallway 2"){
				cin >> dir;
				if(dir == "west"){
					pos = "west hallway 2";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "north hallway 2";
					cout << loc + pos + ent;
				}if(dir == "east"){
					pos = "east hallway 2";
					cout << loc + pos + ent;
				}if(dir == "south"){
					pos = "south hallway 2";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*WEST HALLWAY 2*/
			while(pos == "west hallway 2"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "meeting hall";
					cout << loc + pos + ent;
				}if(dir == "east"){
					pos = "central hallway 2";
					cout << loc + pos + ent;
				}if(dir == "south"){
					pos = "west staircase 2";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*NORTH HALLWAY 2*/
			while(pos == "north hallway 2"){
				cin >> dir;
				if(dir == "west"){
				pos = "the king\'s throne";
					cout << loc + pos + ent;
					cout << "you are doomed! Press enter to continue...\n";
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					pos = "master bedroom";
					cout << loc + pos + ent;
				}if(dir == "south"){
					pos = "central hallway 2";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*EAST HALLWAY 2*/
			while(pos == "east hallway 2"){
				cin >> dir;
				if(dir == "west"){
				pos = "central hallway 2";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "restroom 2";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "east staircase 2";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*SOUTH HALLWAY 2*/
			while(pos == "south hallway 2"){
				cin >> dir;
				if(dir == "west"){
				pos = "gallery";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "central hallway 2";
					cout << loc + pos + ent;
				}if(dir == "east"){
					pos = "grand ballroom";
					cout << loc + pos + ent;
					cout << "you have found the key, head to the gate to get out...\n";
					havekey = 1;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
			
/*
WEST HALLWAY 2 ELEMENTS
*/
/*meeting hall*/
			while(pos == "meeting hall"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "west hallway 2";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*west staircase 2*/
			while(pos == "west staircase 2"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "west hallway 2";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}if(dir == "up"){
					cout << "already at the highest level\n";
				}if(dir == "down"){
					pos = "west staircase 1";
					level = "1";
					cout << lol + level + ent;
					cout << loc + pos + ent;
				}
			}
/*
NORTH HALLWAY 2
*/
/*the king's throne*/
/*the king's throne is currently a doomed*/
/*master bedroom*/
			while(pos == "master bedroom"){
				cin >> dir;
				if(dir == "west"){
					pos = "north hallway 2";
					cout << loc + pos + ent;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*
EAST HALLWAY 2 ELEMENTS
*/
/*restroom 2*/
			while(pos == "restroom 2"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "east hallway 2";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*east staircase 2*/
			while(pos == "east staircase 2"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "east hallway 2";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}if(dir == "up"){
					cout << "already at the highest level\n";
				}if(dir == "down"){
					pos = "east staircase 1";
					level = "1";
					cout << lol + level + ent;
					cout << loc + pos + ent;
				}
			}
/*
SOUTH HALLWAY ELEMENTS
*/
/*gallery*/
			while(pos == "gallery"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					pos = "south hallway 2";
					cout << loc + pos + ent;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*grand ballroom*/
			while(pos == "grand ballroom"){
				cin >> dir;
				if(dir == "west"){
					pos = "south hallway 2";
					cout << loc + pos + ent;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
		}
		
				/*
		
				THIS IS FOR LEVEL 0
		
				*/
		
		while(level == "0"){
/*CENTRAL HALLWAY 0*/
			while(pos == "central hallway 0"){
				cin >> dir;
				if(dir == "west"){
					pos = "west hallway 0";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "north hallway 0";
					cout << loc + pos + ent;
				}if(dir == "east"){
					pos = "east hallway 0";
					cout << loc + pos + ent;
				}if(dir == "south"){
					pos = "south hallway 0";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*WEST HALLWAY 0*/
			while(pos == "west hallway 0"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "dungeon A";
					cout << loc + pos + ent;
				}if(dir == "east"){
					pos = "central hallway 0";
					cout << loc + pos + ent;
				}if(dir == "south"){
					pos = "west staircase 0";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*NORTH HALLWAY 0*/
			while(pos == "north hallway 0"){
				cin >> dir;
				if(dir == "west"){
				pos = "dungeon B";
					cout << loc + pos + ent;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					pos = "dungeon C";
					cout << loc + pos + ent;
					cout << "you are doomed! Press enter to continue...\n";
				}if(dir == "south"){
					pos = "central hallway 0";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*EAST HALLWAY 0*/
			while(pos == "east hallway 0"){
				cin >> dir;
				if(dir == "west"){
				pos = "central hallway 0";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "restroom 0";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "east staircase 0";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*SOUTH HALLWAY 0*/
			while(pos == "south hallway 0"){
				cin >> dir;
				if(dir == "west"){
				pos = "dungeon E";
					cout << loc + pos + ent;
				}if(dir == "north"){
					pos = "central hallway 0";
					cout << loc + pos + ent;
				}if(dir == "east"){
					pos = "dungeon D";
					cout << loc + pos + ent;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
			
/*
WEST HALLWAY 0 ELEMENTS
*/
/*dungeon A*/
			while(pos == "dungeon A"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "west hallway 0";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*west staircase 0*/
			while(pos == "west staircase 0"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "west hallway 0";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}if(dir == "up"){
					pos = "west staircase 1";
					level = "1";
					cout << lol + level + ent;
					cout << loc + pos + ent;
				}if(dir == "down"){
					cout << "already at the lowest level\n";
				}
			}
/*
NORTH HALLWAY 0
*/
/*dungeon B*/
			while(pos == "dungeon B"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					pos = "north hallway 0";
					cout << loc + pos + ent;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*dungeon C*/
/*dungeon C is currently a doomed*/
/*
EAST HALLWAY 0 ELEMENTS
*/
/*restroom 0*/
			while(pos == "restroom 0"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					pos = "east hallway 0";
					cout << loc + pos + ent;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*east staircase 0*/
			while(pos == "east staircase 0"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					pos = "east hallway 0";
					cout << loc + pos + ent;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}if(dir == "up"){
					pos = "east staircase 1";
					level = "1";
					cout << lol + level + ent;
					cout << loc + pos + ent;
				}if(dir == "down"){
					cout << "already at the lowest level\n";
				}
			}
/*
SOUTH HALLWAY ELEMENTS
*/
/*dungeon E*/
			while(pos == "dungeon E"){
				cin >> dir;
				if(dir == "west"){
					cout << walls;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					pos = "south hallway 0";
					cout << loc + pos + ent;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
/*dungeon D*/
			while(pos == "dungeon D"){
				cin >> dir;
				if(dir == "west"){
					pos = "south hallway 0";
					cout << loc + pos + ent;
				}if(dir == "north"){
					cout << walls;
				}if(dir == "east"){
					cout << walls;
				}if(dir == "south"){
					cout << walls;
				}if(dir == "read"){
					if(havecard == 1){
						card();
					}
				}
			}
		}
	}
}
